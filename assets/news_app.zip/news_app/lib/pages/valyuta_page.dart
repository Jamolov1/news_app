import 'package:flutter/material.dart';
import 'package:news_app/model/user_model.dart';
import 'package:news_app/model/valyuta_model.dart';
import 'package:news_app/service/album_service.dart';
import 'package:news_app/service/user_service.dart';
import 'package:news_app/service/valyuta_service.dart';

class ValyutaPage extends StatefulWidget {
  const ValyutaPage({super.key});

  @override
  State<ValyutaPage> createState() => _ValyutaPageState();
}

class _ValyutaPageState extends State<ValyutaPage> {
  List<ValyutaModel> items = [];
  var isLoading = false;

  void apiUserList() async {
    setState(() {
      isLoading = true;
    });
    var response = await ValyutaService.GET();
    setState(() {
      isLoading = false;
      items = ValyutaService.parseUsersList(response);
      print(items);
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    apiUserList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          ListView.builder(
            itemBuilder: (ctx, index) {
              return Card(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(items[index].ccyNmUz,style: TextStyle(color: Colors.blue,fontSize: 20,fontWeight: FontWeight.bold),),
                      Text(items[index].nominal,style: TextStyle(fontSize: 20),),
                      Text(items[index].rate,style: TextStyle(color: Colors.red,fontSize: 18),),
                      Text(items[index].id.toString()),
                      Text(items[index].rate),
                    ],
                  )
              );
            },
            itemCount: items.length,
          ),
          isLoading
              ? Center(
            child: CircularProgressIndicator(),
          )
              : SizedBox(),
        ],
      ),
    );
  }
}
