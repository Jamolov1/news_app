import 'package:flutter/material.dart';
import 'package:news_app/model/photos_model.dart';
import 'package:news_app/service/photos_service.dart';

class PhotosPage extends StatefulWidget {
  const PhotosPage({super.key});

  @override
  State<PhotosPage> createState() => _PhotosPageState();
}

class _PhotosPageState extends State<PhotosPage> {
  List<Photos> items = [];
  var isLoading = false;

  void apiPhotosList() async {
    setState(() {
      isLoading = true;
    });
    var response = await PhotosService.GET(
        PhotosService.apiPhotos, PhotosService.PhotosParamsEmpty());
    setState(() {
      isLoading = false;
      items = PhotosService.parsePhotosList(response);
      print(items);
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    apiPhotosList();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          ListView.builder(
            itemBuilder: (ctx, index) {
              return Card(
                child: ListTile(
                  title: Text(
                    items[index].title,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  subtitle: Image.network(
                    items[index].url,
                  ),
                ),
              );
            },
            itemCount: items.length,
          ),
          isLoading ? Center(child: CircularProgressIndicator()): SizedBox(),
        ],
      ),
    );
  }
}
